from aws_cdk import (
    Stack,
    aws_lambda as _lambda,
    aws_dynamodb as dynamodb,
    aws_apigateway as apigateway,
    aws_logs as logs,
    aws_iam as iam,
    CfnOutput,
)
from constructs import Construct
from aws_cdk import Duration


class SkincareCdkStack(Stack):

    def __init__(self, scope: Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)

        # Create a DynamoDB table with sessionId as the primary key
        recommendations_table = dynamodb.Table(
            self,
            "RecommendationsTable",
            partition_key=dynamodb.Attribute(
                name="sessionId", type=dynamodb.AttributeType.STRING
            ),
            billing_mode=dynamodb.BillingMode.PAY_PER_REQUEST,
        )

        # Create the productScraper Lambda function
        product_scraper_function = _lambda.Function(
            self,
            "ProductScraperFunction",
            runtime=_lambda.Runtime.PYTHON_3_13,
            handler="app.lambda_handler",
            code=_lambda.Code.from_asset("../lambda_functions/productScraper"),
            memory_size=1024,
            timeout=Duration.minutes(2),
        )

        # Create the analyzeFace Lambda function
        analyze_face_function = _lambda.Function(
            self,
            "AnalyzeFaceFunction",
            runtime=_lambda.Runtime.PYTHON_3_13,
            handler="app.lambda_handler",  # Adjust based on your file structure
            code=_lambda.Code.from_asset("../lambda_functions/analyzeFace"),
            environment={"DYNAMODB_TABLE_NAME": recommendations_table.table_name},
            memory_size=256,
            timeout=Duration.minutes(10),
        )

        # Grant permissions to invoke Bedrock model
        analyze_face_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=["bedrock:InvokeModel"],
                resources=[
                    "arn:aws:bedrock:us-east-1::foundation-model/*",
                ],  # Adjust this ARN if necessary
            )
        )

        # Grant permissions to detect faces using Rekognition
        analyze_face_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=["rekognition:DetectFaces"],
                resources=["*"],
            )
        )

        # Grant permissions to write to DynamoDB
        recommendations_table.grant_read_write_data(analyze_face_function)

        # Create the getRecommendation Lambda function (similar permissions can be added here)
        get_recommendation_function = _lambda.Function(
            self,
            "GetRecommendationFunction",
            runtime=_lambda.Runtime.PYTHON_3_13,
            handler="app.lambda_handler",  # Adjust based on your file structure
            code=_lambda.Code.from_asset("../lambda_functions/getRecommendation"),
            memory_size=2048,
            environment={
                "DYNAMODB_TABLE_NAME": recommendations_table.table_name,
                "AGENT_ID": "12QS2C6G4P",
                "AGENT_ALIAS_ID": "VP4WNAJ44Q",
            },
            timeout=Duration.minutes(10),
        )

        # Grand permissions to invoke Bedrock model
        get_recommendation_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=["bedrock:InvokeModel"],
                resources=[
                    "arn:aws:bedrock:us-east-1::foundation-model/*",
                ],  # Adjust this ARN if necessary
            )
        )

        # Grant permissions to Invoke Bedrock Agent
        get_recommendation_function.add_to_role_policy(
            iam.PolicyStatement(
                actions=["bedrock:InvokeAgent"],
                resources=[
                    "arn:aws:bedrock:us-east-1:677276081751:agent-alias/12QS2C6G4P/VP4WNAJ44Q",
                ],  # Adjust this ARN if necessary
            )
        )

        # Grant permissions to write to DynamoDB for getRecommendation function
        recommendations_table.grant_read_write_data(get_recommendation_function)

        # Optionally create an API Gateway for both functions
        api = apigateway.RestApi(self, "SkincareApi")

        analyze_face_integration = api.root.add_resource("analyze")
        analyze_face_integration.add_method(
            "POST", apigateway.LambdaIntegration(analyze_face_function)
        )

        get_recommendation_integration = api.root.add_resource("recommend")
        get_recommendation_integration.add_method(
            "POST", apigateway.LambdaIntegration(get_recommendation_function)
        )

        CfnOutput(
            self,
            "AnalyzeFaceFunctionName",
            value=analyze_face_function.function_name,
            description="The name of the AnalyzeFace Lambda function",
        )

        CfnOutput(
            self,
            "GetRecommendationFunctionName",
            value=get_recommendation_function.function_name,
            description="The name of the GetRecommendation Lambda function",
        )

        CfnOutput(
            self,
            "ProductScraperFunctionName",
            value=product_scraper_function.function_name,
            description="The name of the ProductScraper Lambda function",
        )
