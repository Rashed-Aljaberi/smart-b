import streamlit as st


def results_page(nav_context):
    # Create a container for the entire page content
    main_container = st.container()

    if "transition_started" in st.session_state:
        # Clear the container first
        main_container.empty()
        # Show only the loader
        st.markdown(
            """
            <div class="fullscreen-loader">
                <div class="loader-content">
                    <div class="loading-dots"></div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        # Don't show anything else
        st.stop()

    with main_container:
        st.markdown('<div class="selection-container">', unsafe_allow_html=True)

        # Center the title
        st.markdown(
            """
            <h1 style='text-align: center; 
            color: #1f618d; 
            padding: 20px 0; 
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
            font-weight: 300;'>
            Analysis Results
            </h1>
            """,
            unsafe_allow_html=True,
        )

        if "results" in st.session_state:
            results = st.session_state.results

            st.markdown(
                """
                <p style='text-align: center; margin-bottom: 2rem;'>
                Please confirm that the following analysis is accurate. You can change any of the details below.
                </p>
                """,
                unsafe_allow_html=True,
            )

            # Dropdown options
            skin_type_options = [
                "Normal",
                "Dry",
                "Oily",
                "Combination",
                "Combination to oily",
            ]
            skin_health_options = ["Excellent", "Good", "Fair", "Poor", "Moderate"]
            age_range_options = ["18-24", "25-34", "35-44", "45-54", "55+"]
            gender_options = ["Female", "Male", "Other"]
            skin_concerns_options = [
                "Acne",
                "Wrinkles",
                "Pigmentation",
                "Sensitivity",
                "Dryness",
                "Redness",
                "Uneven Texture",
            ]

            with st.form("update_analysis"):
                skin_type = results.get("skinType", skin_type_options[0])
                if skin_type not in skin_type_options:
                    skin_type_options.append(skin_type)
                new_skin_type = st.selectbox(
                    "Skin Type",
                    skin_type_options,
                    index=skin_type_options.index(skin_type),
                )

                skin_health = results.get("skinHealth", skin_health_options[0])
                if skin_health not in skin_health_options:
                    skin_health_options.append(skin_health)
                new_skin_health = st.selectbox(
                    "Skin Health",
                    skin_health_options,
                    index=skin_health_options.index(skin_health),
                )

                gender = results.get("gender", gender_options[0])
                if gender not in gender_options:
                    gender_options.append(gender)
                new_gender = st.selectbox(
                    "Gender", gender_options, index=gender_options.index(gender)
                )

                age = results.get("estimatedAge", age_range_options[0])
                if age not in age_range_options:
                    age_range_options.append(age)
                new_age = st.selectbox(
                    "Age Range", age_range_options, index=age_range_options.index(age)
                )

                valid_concerns = results.get("skinConcerns", [])
                for concern in valid_concerns:
                    if concern not in skin_concerns_options:
                        skin_concerns_options.append(concern)
                new_concerns = st.multiselect(
                    "Skin Concerns", skin_concerns_options, default=valid_concerns
                )

                additional_info = st.text_area(
                    "Additional Information (e.g., allergies)", height=100
                )

                # Add custom styling for the button
                st.markdown(
                    """
                    <style>
                    [data-testid="stForm"] .stButton > button {
                        width: 100% !important;
                        margin: 0 !important;
                    }
                    </style>
                    """,
                    unsafe_allow_html=True,
                )

                confirm_button = st.form_submit_button(
                    "Confirm Analysis", use_container_width=True
                )

                if confirm_button:
                    # Set transition state
                    st.session_state.transition_started = True

                    # Update results
                    results["skinType"] = new_skin_type
                    results["skinHealth"] = new_skin_health
                    results["gender"] = new_gender
                    results["estimatedAge"] = new_age
                    results["skinConcerns"] = new_concerns
                    results["additionalInfo"] = additional_info

                    # Update navigation history
                    st.session_state.page_history = st.session_state.page_history[
                        : st.session_state.current_page_idx + 1
                    ]
                    st.session_state.page_history.append("routine")
                    st.session_state.current_page_idx += 1

                    # Show loading animation
                    st.markdown(
                        """
                        <div class="fullscreen-loader">
                            <div class="loader-content">
                                <div class="loading-dots"></div>
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                    st.rerun()

        else:
            st.error("Face analysis data is not available.")

        st.markdown("</div>", unsafe_allow_html=True)
