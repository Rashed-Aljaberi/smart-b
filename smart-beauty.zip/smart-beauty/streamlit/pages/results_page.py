import streamlit as st
from utils import navigate_arrow_button


def results_page():
    navigate_arrow_button()
    st.title("Analysis Results")

    print("Session state:", st.session_state)
    print("Results in session:", "results" in st.session_state)
    if "results" in st.session_state:
        print("Results content:", st.session_state.results)
        results = st.session_state.results

        st.markdown(
            "Please confirm that the following analysis is accurate. You can change any of the details below."
        )

        # Dropdown options
        skin_type_options = [
            "Normal",
            "Dry",
            "Oily",
            "Combination",
            "Combination to oily",
        ]
        skin_health_options = ["Excellent", "Good", "Fair", "Poor", "Moderate"]
        age_range_options = ["18-24", "25-34", "35-44", "45-54", "55+"]
        gender_options = ["Female", "Male", "Other"]
        skin_concerns_options = [
            "Acne",
            "Wrinkles",
            "Pigmentation",
            "Sensitivity",
            "Dryness",
            "Redness",
            "Uneven Texture",
        ]

        with st.form("update_analysis"):
            # Existing user input data
            skin_type = results.get("skinType", skin_type_options[0])
            if skin_type not in skin_type_options:
                skin_type_options.append(skin_type)
            new_skin_type = st.selectbox(
                "Skin Type", skin_type_options, index=skin_type_options.index(skin_type)
            )

            skin_health = results.get("skinHealth", skin_health_options[0])
            if skin_health not in skin_health_options:
                skin_health_options.append(skin_health)
            new_skin_health = st.selectbox(
                "Skin Health",
                skin_health_options,
                index=skin_health_options.index(skin_health),
            )

            gender = results.get("gender", gender_options[0])
            if gender not in gender_options:
                gender_options.append(gender)
            new_gender = st.selectbox(
                "Gender", gender_options, index=gender_options.index(gender)
            )

            age = results.get("estimatedAge", age_range_options[0])
            if age not in age_range_options:
                age_range_options.append(age)
            new_age = st.selectbox(
                "Age Range", age_range_options, index=age_range_options.index(age)
            )

            valid_concerns = results.get("skinConcerns", [])
            for concern in valid_concerns:
                if concern not in skin_concerns_options:
                    skin_concerns_options.append(concern)

            new_concerns = st.multiselect(
                "Skin Concerns", skin_concerns_options, default=valid_concerns
            )

            additional_info = st.text_area("Additional Information (e.g., allergies)")

            # Form submission button
            confirm_button = st.form_submit_button("Confirm Analysis")

            if confirm_button:
                # Show the spinner while processing
                with st.spinner("Processing..."):
                    # Update session state with new inputs
                    results["skinType"] = new_skin_type
                    results["skinHealth"] = new_skin_health
                    results["gender"] = new_gender
                    results["estimatedAge"] = new_age
                    results["skinConcerns"] = new_concerns
                    results["additionalInfo"] = additional_info
                    # Set the page to 'routine' to navigate to the routine page
                    st.session_state.page = "routine"

                    # Trigger the rerun to load the next page
                    st.rerun()

    else:
        st.error("Face analysis data is not available.")
