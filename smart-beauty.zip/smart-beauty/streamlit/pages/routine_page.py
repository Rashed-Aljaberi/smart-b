# pages/routine_page.py
import streamlit as st
import json
import asyncio
from utils import get_recommendations, fetch_product_details


def routine_page(function_names, logger):
    st.title("Your Personalized Skincare Routine")

    if "basket" not in st.session_state:
        st.session_state.basket = []

    if "results" in st.session_state:
        results = st.session_state.results
        placeholder_image_url = "https://8c3412d76225d04d7baa-be98b6ea17920953fb931282eff9a681.images.lovelyskin.com/fk4rdxrf_202405161712120966.jpg"

        with st.container():
            with st.spinner("Fetching recommendations..."):
                try:
                    recommendations = get_recommendations(
                        function_names["get_recommendation"],
                        results["estimatedAge"],
                        results["skinType"].lower(),
                        results["gender"].lower(),
                        results["skinHealth"],
                        results["skinConcerns"],
                        "",
                        logger,
                    )

                    if recommendations["success"]:
                        routine_data = json.loads(recommendations["data"])

                        # Display all steps immediately
                        for step in routine_data["routine"]:
                            st.markdown(
                                f"""
                                <div style="background-color: #bad4f0; padding: 15px; border-radius: 10px; border: 1px solid #d1d1d1; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); margin-bottom: 20px;">
                                    <h4>{step['step']}</h4>
                                    <div style="font-weight: bold;">Product Name:</div>
                                    <p>{step['product']}</p>
                                    <div style="font-weight: bold;">Benefits:</div>
                                    <p>{step['benefits']}</p>
                                    <div style="font-weight: bold;">Alternative:</div>
                                    <p>{step['alternative']}</p>
                                    <div style="font-weight: bold;">Price:</div>
                                    <p>{step['price']}</p>
                                    <div style="font-weight: bold;">Score:</div>
                                    <p>{step['score']} % match</p>
                                </div>
                                """,
                                unsafe_allow_html=True,
                            )
                            options = [step["product"], step["alternative"]]
                            selection = st.selectbox(
                                f"Choose product for {step['step']}:", options
                            )

                            if st.button(f"Add {selection} to basket"):
                                product_price = (
                                    step["price"]
                                    if selection == step["product"]
                                    else step["alternative_price"]
                                )
                                st.session_state.basket.append(
                                    {
                                        "step": step["step"],
                                        "product": selection,
                                        "price": product_price,
                                    }
                                )
                                st.success(f"{selection} added to basket!")

                            step["placeholder"] = st.empty()

                        async def load_products():
                            tasks = [
                                fetch_product_details(
                                    step["product"], function_names["product_scraper"]
                                )
                                for step in routine_data["routine"]
                            ]
                            product_details_list = await asyncio.gather(*tasks)

                            for step, product_details in zip(
                                routine_data["routine"], product_details_list
                            ):
                                product_image_url = (
                                    product_details["product_image"]
                                    if product_details
                                    and product_details["product_image"]
                                    else placeholder_image_url
                                )

                                with step["placeholder"].container():
                                    col1, col2, col3 = st.columns([1, 1, 1])
                                    with col1:
                                        st.markdown(
                                            '<div class="product-column">',
                                            unsafe_allow_html=True,
                                        )
                                        try:
                                            st.image(product_image_url, width=100)
                                        except Exception as e:
                                            st.warning("Unable to load image")
                                            logger.error(f"Image load error: {str(e)}")
                                    with col2:
                                        if (
                                            product_details
                                            and product_details["product_link"]
                                        ):
                                            st.markdown(
                                                f"[Product Link]({product_details['product_link']})"
                                            )
                                    with col3:
                                        st.write(f"{step['price']}")

                        st.write("Loading product recommendations...")
                        asyncio.run(load_products())

                        # Display basket and total cost
                        st.subheader("Your Basket")
                        if st.session_state.basket:
                            total_cost = 0
                            for item in st.session_state.basket:
                                st.write(
                                    f"{item['step']}: {item['product']} - {item['price']}"
                                )
                                try:
                                    total_cost += float(item["price"].replace("$", ""))
                                except ValueError:
                                    st.warning(
                                        f"Could not parse price for {item['product']}"
                                    )
                                    logger.warning(
                                        f"Price parsing error for {item['product']}: {item['price']}"
                                    )
                            st.write(f"Total Cost: ${total_cost:.2f}")
                        else:
                            st.write("Your basket is empty.")

                        if st.button("Clear Basket"):
                            st.session_state.basket = []
                            st.success("Basket cleared!")

                    else:
                        if recommendations.get("error") == "throttling":
                            st.error(
                                "We are experiencing high demand. Please try again in a few minutes."
                            )
                            if st.button("Try Again"):
                                st.rerun()
                        else:
                            error_message = recommendations.get(
                                "error", "Unknown error occurred"
                            )
                            st.error(
                                f"Unable to generate recommendations: {error_message}"
                            )
                            logger.error(f"Recommendation error: {error_message}")
                            if st.button("Try Again"):
                                st.session_state.page = "results"
                                st.rerun()

                except Exception as e:
                    st.error(f"An unexpected error occurred: {str(e)}")
                    logger.exception("Unexpected error in routine_page")
                    if st.button("Try Again"):
                        st.session_state.page = "results"
                        st.rerun()

    else:
        st.error("No results found. Please start over.")
        logger.error("No results found in session state")

    if st.button(
        "Start Over",
        key="start_over",
        help="Reset the session",
        use_container_width=False,
    ):
        st.session_state.page = "selection"
        st.session_state.results = None
        st.session_state.face_analysis = None
        st.session_state.basket = []
        st.rerun()
