import streamlit as st
import json
import asyncio
import plotly.express as px
import pandas as pd
from utils import get_recommendations, fetch_product_details


async def load_products(routine_data, function_names):
    loading_placeholder = st.markdown(
        """
        <div class="fullscreen-loader">
            <div class="loader-content">
                <div class="loading-dots"></div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    tasks = [
        fetch_product_details(
            step["product"],
            function_names["product_scraper"],
        )
        for step in routine_data["routine"]
    ]
    alt_tasks = [
        fetch_product_details(
            step["alternative"],
            function_names["product_scraper"],
        )
        for step in routine_data["routine"]
    ]

    all_results = await asyncio.gather(*tasks, *alt_tasks)
    main_results = all_results[: len(tasks)]
    alt_results = all_results[len(tasks) :]

    loading_placeholder.empty()
    return list(zip(main_results, alt_results))


def routine_page(function_names, logger, nav_context):
    loading_placeholder = st.empty()
    loading_placeholder.markdown(
        """
        <div class="fullscreen-loader">
            <div class="loader-content">
                <div class="loading-dots"></div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if "transition_started" in st.session_state:
        del st.session_state.transition_started

    try:
        # Get recommendations
        recommendations = get_recommendations(
            function_names["get_recommendation"],
            st.session_state.results["estimatedAge"],
            st.session_state.results["skinType"].lower(),
            st.session_state.results["gender"].lower(),
            st.session_state.results["skinHealth"],
            st.session_state.results["skinConcerns"],
            "",
            logger,
        )

        if recommendations and recommendations.get("success"):
            placeholder_image_url = "https://8c3412d76225d04d7baa-be98b6ea17920953fb931282eff9a681.images.lovelyskin.com/fk4rdxrf_202405161712120966.jpg"

            if isinstance(recommendations["data"], str):
                routine_data = json.loads(recommendations["data"])
            else:
                routine_data = recommendations["data"]

            if "routine" not in routine_data:
                loading_placeholder.empty()
                st.error("Invalid response format")
                return

            # Load all products asynchronously first
            product_pairs = asyncio.run(load_products(routine_data, function_names))

            # Remove loading animation
            loading_placeholder.empty()

            # Display content
            st.markdown('<div class="selection-container">', unsafe_allow_html=True)

            st.markdown(
                """
                <h1 style='text-align: center; 
                color: #1f618d; 
                padding: 20px 0; 
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                font-weight: 200;'>
                Your Personalized Skincare Routine
                </h1>
                """,
                unsafe_allow_html=True,
            )

            """
            # Initialize basket if it doesn't exist
            # if "basket" not in st.session_state:
            #     st.session_state.basket = []
            """
            # Display products
            for idx, ((main_product, alt_product), step) in enumerate(
                zip(product_pairs, routine_data["routine"])
            ):
                # Step header
                margin_top = "40px" if idx > 0 else "20px"
                st.markdown(
                    f"""
                    <div style="background-color: #bad4f0; padding: 15px; border-radius: 10px; border: 1px solid #d1d1d1; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); margin: {margin_top} 0 20px 0;">
                        <h4>{step['step']}</h4>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

                col1, col2 = st.columns(2)

                main_score = int(step["score"])
                alt_score = max(0, main_score - 5)

                # Main product
                with col1:
                    product_image_url = (
                        main_product["product_image"]
                        if main_product and main_product.get("product_image")
                        else placeholder_image_url
                    )
                    product_link = (
                        main_product["product_link"]
                        if main_product and main_product.get("product_link")
                        else f"https://www.amazon.fr/s?k={step['product'].replace(' ', '+')}"
                    )

                    st.markdown(
                        f"""
                        <div class="product-recommendation-card">
                            <h5 style="margin-bottom: 12px;">Recommended Product</h5>
                            <div class="product-images-container" style="flex-shrink: 0;">
                                <div class="product-image">
                                    <img src="{product_image_url}" alt="{step['product']}" class="product-img">
                                    <a href="{product_link}" target="_blank" class="product-link">View Product</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <div class="product-name">{step['product']}</div>
                                <div class="product-benefits">{step['benefits']}</div>
                                <div class="product-price" style="margin-top: auto;">{step['price']}</div>
                                <div class="product-score">{main_score}% match</div>
                            </div>
                            <button class="refresh-button"></button>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                    """
                    # if st.button(
                    #     f"Add to basket",
                    #     key=f"add_main_{step['step']}",
                    # ):
                    #     st.session_state.basket.append({
                    #         "step": step["step"],
                    #         "product": step["product"],
                    #         "price": step["price"],
                    #     })
                    #     st.success(f"{step['product']} added to basket!")
                    """

                # Alternative product
                with col2:
                    alt_product_link = f"https://www.amazon.fr/s?k={step['alternative'].replace(' ', '+')}"
                    st.markdown(
                        f"""
                        <div class="product-recommendation-card alternative">
                            <h5 style="margin-bottom: 12px;">Alternative Product</h5>
                            <div class="product-images-container" style="flex-shrink: 0;">
                                <div class="product-image">
                                    <img src="{placeholder_image_url}" alt="{step['alternative']}" class="product-img">
                                    <a href="{alt_product_link}" target="_blank" rel="noopener noreferrer" class="product-link">View on Amazon</a>
                                </div>
                            </div>
                            <div class="product-details">
                                <div class="product-name">{step['alternative']}</div>
                                <div class="product-benefits">{step['benefits']}</div>
                                <div class="product-price" style="margin-top: auto;">{step['price']}</div>
                                <div class="product-score">{alt_score}% match</div>
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                    """
                    # if st.button(
                    #     f"Add to basket",
                    #     key=f"add_alt_{step['step']}",
                    # ):
                    #     st.session_state.basket.append({
                    #         "step": step["step"],
                    #         "product": step["alternative"],
                    #         "price": step["price"],
                    #     })
                    #     st.success(f"{step['alternative']} added to basket!")
                    """

            """
            # Basket Section
            # if st.session_state.basket:
            #     basket_col, chart_col = st.columns([1, 1])
            #     
            #     with basket_col:
            #         st.markdown(
            #             '''
            #             <div class="basket-container">
            #                 <h3>Your Basket</h3>
            #             ''',
            #             unsafe_allow_html=True,
            #         )
            #         
            #         total_cost = 0
            #         items_df = {
            #             "Step": [],
            #             "Cost": [],
            #         }
            #         
            #         for item in st.session_state.basket:
            #             st.markdown(
            #                 f'''
            #                 <div class="basket-item">
            #                     <span>{item['step']}: {item['product']}</span>
            #                     <span>{item['price']}</span>
            #                 </div>
            #                 ''',
            #                 unsafe_allow_html=True,
            #             )
            #             try:
            #                 price = float(item["price"].replace("$", ""))
            #                 total_cost += price
            #                 items_df["Step"].append(item["step"].split(": ")[1])
            #                 items_df["Cost"].append(price)
            #             except ValueError:
            #                 st.warning(f"Could not parse price for {item['product']}")
            #                 logger.warning(f"Price parsing error for {item['product']}: {item['price']}")
            #         
            #         st.markdown(
            #             f'''
            #             <div class="total-cost">
            #                 Total Cost: ${total_cost:.2f}
            #             </div>
            #             ''',
            #             unsafe_allow_html=True,
            #         )
            #         
            #         if st.button("Clear Basket", key="clear_basket_button"):
            #             st.session_state.basket = []
            #             st.rerun()
            #     
            #     with chart_col:
            #         if items_df["Step"]:
            #             chart_df = pd.DataFrame(items_df)
            #             fig = px.pie(
            #                 chart_df,
            #                 values="Cost",
            #                 names="Step",
            #                 title="Cost Distribution",
            #                 color_discrete_sequence=["#439cfb", "#f187fb", "#bad4f0", "#e2e8f0"],
            #             )
            #             fig.update_traces(
            #                 textposition="inside",
            #                 textinfo="percent+label",
            #                 textfont=dict(family="Helvetica Neue"),
            #             )
            #             fig.update_layout(
            #                 showlegend=False,
            #                 paper_bgcolor="rgba(0,0,0,0)",
            #                 plot_bgcolor="rgba(0,0,0,0)",
            #                 margin=dict(t=30, l=0, r=0, b=0),
            #                 font=dict(family="Helvetica Neue"),
            #                 title_font=dict(
            #                     family="Helvetica Neue",
            #                     size=16,
            #                     color="#1a202c",
            #                 ),
            #                 width=300,
            #                 height=300,
            #             )
            #             st.plotly_chart(fig, use_container_width=True)
            # else:
            #     st.markdown(
            #         '''
            #         <div class="basket-container">
            #             <h3>Your Basket</h3>
            #             <div class="basket-item">
            #                 Your basket is empty.
            #             </div>
            #         </div>
            #         ''',
            #         unsafe_allow_html=True,
            #     )
            """

        else:
            st.error("Unable to generate recommendations. Please try again.")
            if st.button("Try Again"):
                st.session_state.pop("routine_data", None)
                st.rerun()

    except Exception as e:
        logger.exception("Error in routine page")
        st.error(f"An unexpected error occurred: {str(e)}")
        if st.button("Try Again"):
            st.session_state.pop("routine_data", None)
            st.rerun()

    if st.button(
        "Start Over",
        key="start_over",
        help="Reset the session",
        use_container_width=False,
    ):
        for key in list(st.session_state.keys()):
            del st.session_state[key]
        st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)
