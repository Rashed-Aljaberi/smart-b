import streamlit as st


def handle_nav(nav_context, category):
    st.session_state["category"] = category
    nav_context["navigate_to"]("upload")
    st.rerun()


def selection_page(nav_context):
    # Hide default elements
    st.markdown(
        """
        <style>
        #MainMenu {visibility: hidden;}
        header {visibility: hidden;}
        .stTitle {display: none;}
        [data-testid="stHeader"] {display: none;}
        </style>
        """,
        unsafe_allow_html=True,
    )

    # Add the blue tag/banner
    st.markdown(
        """
        <div style='text-align: center;'>
            <div class='brand-tag'>
                SmartBeauty is here!
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Title and subtitle
    st.markdown(
        """
        <div style='text-align: center; width: 100%; max-width: 600px; margin: 0 auto;'>
            <h3 style='font-size: 2.5rem; line-height: 1.2; text-align: center; font-weight: 500;'>
                Science-backed<br>
                AI Cosmetologist<br>
                you can trust
            </h3>
            <p style='font-size: 1.2rem; font-weight: 500; text-align: center;'>
                Focused around you and your beauty
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Add space between text and buttons
    st.markdown("<div style='height: 2rem;'></div>", unsafe_allow_html=True)

    # Buttons with callbacks
    col1, col2, col3 = st.columns([1.1, 2, 1])
    with col2:
        if st.button("Hair Care"):
            handle_nav(nav_context, "Hair Care")
        if st.button("Skin Care"):
            handle_nav(nav_context, "Skin Care")
        if st.button("Makeup"):
            handle_nav(nav_context, "Makeup")
