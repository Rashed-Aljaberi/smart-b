import streamlit as st


def selection_page():
    st.title("✨Welcome to your AI-Beauty Wizard ✨")

    # Initialize session state
    if "page" not in st.session_state:
        st.session_state.page = "selection"
    if "category" not in st.session_state:
        st.session_state.category = None

    # Create a container for buttons
    button_container = st.container()

    with button_container:
        # Buttons for category selection
        if st.button("Hair Care", key="hair_care"):
            st.session_state.page = "upload"
            st.session_state.category = "Hair Care"
            st.rerun()
        if st.button("Skin Care", key="skin_care"):
            st.session_state.page = "upload"
            st.session_state.category = "Skin Care"
            st.rerun()
        if st.button("Makeup", key="makeup"):
            st.session_state.page = "upload"
            st.session_state.category = "Makeup"
            st.rerun()
