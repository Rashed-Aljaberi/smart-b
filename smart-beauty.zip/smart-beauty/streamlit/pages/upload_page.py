import streamlit as st
import json
import io
from PIL import Image
from utils import analyze_face


def upload_page(function_names, logger, nav_context):
    # Initialize session state variables
    if "face_analysis" not in st.session_state:
        st.session_state.face_analysis = None
    if "button_clicked" not in st.session_state:
        st.session_state.button_clicked = False
    if "show_camera" not in st.session_state:
        st.session_state.show_camera = False
    if "upload_choice" not in st.session_state:
        st.session_state.upload_choice = None
    if "choice" not in st.session_state:
        st.session_state.choice = None
    if "image" not in st.session_state:
        st.session_state.image = None

    st.markdown('<div class="upload-page-container">', unsafe_allow_html=True)
    st.markdown(
        '<h3 class="upload-title">Upload Your Photo</h3>', unsafe_allow_html=True
    )

    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        # Only show method selection buttons if no image is uploaded
        if st.session_state.image is None:
            if st.button("Choose Existing", key="choose_existing"):
                st.session_state.choice = "upload"
                st.rerun()

            if st.button("Take Photo", key="take_photo"):
                st.session_state.choice = "camera"
                st.rerun()

            # Show either file uploader or camera based on choice
            if st.session_state.choice == "upload":
                uploaded_file = st.file_uploader(
                    "Upload Image", type=["jpg", "jpeg", "png"]
                )
                if uploaded_file is not None:
                    st.session_state.image = Image.open(uploaded_file)
                    st.rerun()
            elif st.session_state.choice == "camera":
                camera_image = st.camera_input("Take a photo")
                if camera_image is not None:
                    st.session_state.image = Image.open(camera_image)
                    st.rerun()

        # If image is uploaded, show image and analyze button
        if st.session_state.image is not None:
            st.image(st.session_state.image, use_container_width=True)

            # Create a container for the analyze button
            analyze_button_container = st.empty()

            # Stack buttons vertically
            if not st.session_state.button_clicked:
                if analyze_button_container.button("Analyze", key="analyze_button"):
                    # Update button state immediately
                    analyze_button_container.button(
                        "Generating Skin Profile", disabled=True, key="analyzing_button"
                    )

                    st.session_state.button_clicked = True

                    # Do the analysis immediately
                    img_byte_arr = io.BytesIO()
                    rgb_image = st.session_state.image.convert("RGB")
                    rgb_image.save(img_byte_arr, format="JPEG")
                    img_byte_arr.seek(0)

                    st.session_state.face_analysis = analyze_face(
                        img_byte_arr.getvalue(), function_names["analyze_face"], logger
                    )

                    if st.session_state.face_analysis is not None:
                        try:
                            results = json.loads(
                                st.session_state.face_analysis["output"]["message"][
                                    "content"
                                ][0]["text"]
                            )
                            st.session_state.results = results
                            st.session_state.button_clicked = False

                            # Update navigation history
                            st.session_state.page_history = (
                                st.session_state.page_history[
                                    : st.session_state.current_page_idx + 1
                                ]
                            )
                            st.session_state.page_history.append("results")
                            st.session_state.current_page_idx += 1
                            st.rerun()
                        except (json.JSONDecodeError, KeyError, IndexError) as e:
                            st.error(
                                f"Error processing face analysis results: {str(e)}"
                            )
                            st.session_state.button_clicked = False
                    else:
                        st.error("Face analysis failed. Please try again.")
                        st.session_state.button_clicked = False
            else:
                analyze_button_container.button(
                    "Generating Skin Profile", disabled=True, key="analyzing_button"
                )

            if st.button("Try Another Photo"):
                st.session_state.image = None
                st.session_state.choice = None
                st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)

    return
