# pages/upload_page.py
import streamlit as st
import json
import io
from PIL import Image
from utils import analyze_face, navigate_arrow_button


def upload_page(function_names, logger):
    if "face_analysis" not in st.session_state:
        st.session_state.face_analysis = None
    if "button_clicked" not in st.session_state:
        st.session_state.button_clicked = False
    if "show_camera" not in st.session_state:
        st.session_state.show_camera = False

    st.title("Upload Your Photo")
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        uploaded_file = st.file_uploader("Upload a photo", type=["jpg", "jpeg", "png"])

        st.write("Or")
        if st.button("Take a selfie ! 📷"):
            enable = st.checkbox("Enable camera")
            st.session_state.show_camera = not st.session_state.show_camera

    camera_image = None
    if st.session_state.show_camera:
        camera_image = st.camera_input("Take a picture")

    if uploaded_file is not None:
        image = Image.open(uploaded_file)
    elif camera_image is not None:
        image = Image.open(camera_image)
    else:
        return

    if image:
        bg_color = (0, 0, 0)  # Black
        border_width = 10
        new_image_size = (
            image.width + 2 * border_width,
            image.height + 2 * border_width,
        )
        new_image = Image.new("RGB", new_image_size, bg_color)
        new_image.paste(
            image, (border_width, border_width), image if image.mode == "RGBA" else None
        )

        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.image(new_image, caption="Uploaded Image", use_container_width=True)
            if st.button("Analyze", key="analyze_button"):
                st.session_state.button_clicked = True
                st.rerun()

        if st.session_state.button_clicked:
            with st.spinner("Analyzing your face..."):
                img_byte_arr = io.BytesIO()
                rgb_image = image.convert("RGB")
                rgb_image.save(img_byte_arr, format="JPEG")
                logger.info(
                    f"Image size before processing : {len(img_byte_arr.getvalue())} bytes"
                )

                if len(img_byte_arr.getvalue()) > 6000000:  # 6MB limit
                    logger.info("Image exceeds 6MB limit, resizing...")
                    image = Image.open(io.BytesIO(img_byte_arr.getvalue()))
                    target_size = 2000000  # 2MB limit
                    scale_factor = 0.4
                    while True:
                        img_byte_arr = io.BytesIO()
                        width, height = image.size
                        new_width = int(width * scale_factor)
                        new_height = int(height * scale_factor)
                        resized_image = image.resize(
                            (new_width, new_height), Image.Resampling.LANCZOS
                        )
                        resized_image.convert("RGB").save(img_byte_arr, format="JPEG")
                        img_byte_arr.seek(0)
                        current_size = len(img_byte_arr.getvalue())
                        logger.info(
                            f"Current image size: {current_size} bytes with scale factor {scale_factor}"
                        )
                        if current_size <= target_size:
                            image = resized_image
                            break
                        scale_factor *= 0.9
                        if scale_factor <= 0.1:
                            break

                logger.info(
                    f"Image size after processing: {len(img_byte_arr.getvalue())} bytes"
                )
                img_byte_arr.seek(0)

                st.session_state.face_analysis = analyze_face(
                    img_byte_arr.getvalue(), function_names["analyze_face"], logger
                )

                if st.session_state.face_analysis is not None:
                    try:
                        results = json.loads(
                            st.session_state.face_analysis["output"]["message"][
                                "content"
                            ][0]["text"]
                        )
                        print("Face analysis results:", results)  # Debug print
                        logger.info(f"Face analysis results: {results}")
                        st.session_state.results = results
                        print(
                            "Set results in session:", st.session_state.results
                        )  # Debug print

                        st.session_state.button_clicked = False
                        st.session_state.page = "results"
                        st.rerun()
                    except (json.JSONDecodeError, KeyError, IndexError) as e:
                        st.error(f"Error processing face analysis results: {str(e)}")
                        logger.error(f"Face analysis result processing error: {str(e)}")
                else:
                    st.error("Face analysis failed. Please try again.")
    else:
        st.write("No image uploaded yet.")
    navigate_arrow_button()
