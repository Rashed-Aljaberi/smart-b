import streamlit as st


def custom_nav_back():
    if can_go_back():
        st.session_state.nav_back_clicked = True
        go_back()
        st.rerun()


def custom_nav_forward():
    if can_go_forward():
        st.session_state.nav_forward_clicked = True
        go_forward()
        st.rerun()


def render_nav_buttons():
    # Create a container for the navigation buttons
    nav_col1, nav_col2, _ = st.columns([0.1, 0.1, 2.8])

    with nav_col1:
        if can_go_back():
            if st.button("←", key="nav_back", help="Go back"):
                go_back()
                st.rerun()

    with nav_col2:
        if can_go_forward():
            if st.button("→", key="nav_forward", help="Go forward"):
                go_forward()
                st.rerun()


def navigate_to(page):
    if st.session_state.page_history[st.session_state.current_page_idx] != page:
        st.session_state.page_history = st.session_state.page_history[
            : st.session_state.current_page_idx + 1
        ]
        st.session_state.page_history.append(page)
        st.session_state.current_page_idx = len(st.session_state.page_history) - 1


def can_go_back():
    return st.session_state.current_page_idx > 0


def can_go_forward():
    return st.session_state.current_page_idx < len(st.session_state.page_history) - 1


def go_back():
    if can_go_back():
        st.session_state.current_page_idx -= 1
        return st.session_state.page_history[st.session_state.current_page_idx]
    return None


def go_forward():
    if can_go_forward():
        st.session_state.current_page_idx += 1
        return st.session_state.page_history[st.session_state.current_page_idx]
    return None


def handle_navigation():
    # Handle back navigation
    if st.session_state.get("nav_back_clicked", False):
        st.session_state.nav_back_clicked = False
        if can_go_back():
            go_back()
            st.rerun()

    # Handle forward navigation
    if st.session_state.get("nav_forward_clicked", False):
        st.session_state.nav_forward_clicked = False
        if can_go_forward():
            go_forward()
            st.rerun()
