import boto3
import logging
import json
import base64
from PIL import Image
import streamlit as st
import asyncio


def get_function_names():
    try:
        cfn_client = boto3.client("cloudformation")
        stack_name = "SkincareCdkStack"

        response = cfn_client.describe_stacks(StackName=stack_name)
        outputs = response["Stacks"][0]["Outputs"]

        function_names = {}
        for output in outputs:
            if output["OutputKey"] == "AnalyzeFaceFunctionName":
                function_names["analyze_face"] = output["OutputValue"]
            elif output["OutputKey"] == "GetRecommendationFunctionName":
                function_names["get_recommendation"] = output["OutputValue"]
            elif output["OutputKey"] == "ProductScraperFunctionName":
                function_names["product_scraper"] = output["OutputValue"]

        return function_names
    except Exception as e:
        logging.error(f"Error getting function names: {str(e)}")
        raise Exception(f"Failed to get Lambda function names: {str(e)}")


def add_logo():
    try:
        logo = Image.open("SmartBeauty_Logo_dark.png")
        st.image(logo, width=150)
    except FileNotFoundError:
        st.error("Logo file not found. Please check the file path.")
        logging.error("Logo file not found: SmartBeauty_Logo_dark.png")
    except Exception as e:
        st.error(f"Error loading logo: {str(e)}")
        logging.error(f"Error loading logo: {str(e)}")


def setup_logging():
    try:
        logging.basicConfig(
            format="%(asctime)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            level=logging.INFO,
        )
        return logging.getLogger(__name__)
    except Exception as e:
        print(f"Error setting up logging: {str(e)}")
        raise


def analyze_face(image_bytes, function_name, logger):
    lambda_client = boto3.client("lambda")
    try:
        logger.info("Encoding image to base64")
        encoded_image = base64.b64encode(image_bytes).decode("utf-8")
        logger.info("Invoking analyzeFace Lambda function")

        response = lambda_client.invoke(
            FunctionName=function_name,
            InvocationType="RequestResponse",
            Payload=json.dumps({"image": encoded_image}),
        )

        logger.info("Received response from analyzeFace Lambda")
        result = json.loads(response["Payload"].read())
        logger.info(f"analyzeFace result: {result}")

        if result["statusCode"] == 200:
            return json.loads(result["body"])
        elif result["statusCode"] == 500:
            error_message = json.loads(result.get("body", "{}")).get(
                "error", "Internal Server Error"
            )
            logger.error(f"analyzeFace 500 error: {error_message}")
            st.error(f"Server Error: {error_message}. Please try again later.")
            return None
        else:
            error_message = result.get("body", "Unknown error")
            logger.error(f"Error in analyzeFace: {error_message}")
            st.error(f"Analysis failed: {error_message}")
            return None
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error in analyze_face: {str(e)}")
        st.error("Error processing response from server")
        return None
    except Exception as e:
        logger.error(f"Exception in analyze_face: {str(e)}")
        st.error("An unexpected error occurred during analysis")
        return None


def get_recommendations(
    function_name,
    age,
    skin_type,
    gender,
    skin_health,
    skin_concerns,
    additional_info,
    logger,
):
    lambda_client = boto3.client("lambda")
    try:
        logger.info(
            f"Getting recommendations for age: {age}, skin_type: {skin_type}, gender: {gender}, "
            f"skin_health: {skin_health}, skin_concerns: {skin_concerns}, "
            f"additional_info: {additional_info}"
        )

        payload = json.dumps(
            {
                "age": age,
                "type": skin_type,
                "gender": gender,
                "skin_health": skin_health,
                "skin_concerns": skin_concerns,
                "additional_info": additional_info,
            }
        )

        response = lambda_client.invoke(
            FunctionName=function_name,
            InvocationType="RequestResponse",
            Payload=payload,
        )

        result = json.loads(response["Payload"].read())
        logger.info(f"getRecommendations result: {result}")

        if result["statusCode"] == 200:
            # The response is already a JSON string, so we don't need to parse it again
            return {"success": True, "data": result["body"]}
        elif result["statusCode"] == 500:
            error_body = json.loads(result.get("body", "{}"))
            error_message = error_body.get("error", "Internal Server Error")
            logger.error(f"Recommendations 500 error: {error_message}")
            return {"success": False, "error": f"Server Error: {error_message}"}
        else:
            error_body = json.loads(result.get("body", "{}"))
            if error_body.get("error") == "throttlingException":
                return {"success": False, "error": "throttling"}
            logger.error(f"Error in getRecommendations: {result}")
            return {
                "success": False,
                "error": f"Unexpected error: {result.get('statusCode')}",
            }

    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error in get_recommendations: {str(e)}")
        return {"success": False, "error": "Error processing server response"}
    except Exception as e:
        logger.error(f"Exception in get_recommendations: {str(e)}")
        return {"success": False, "error": f"Unexpected error: {str(e)}"}


def get_product_details(product_name, function_name):
    lambda_client = boto3.client("lambda")
    try:
        payload = json.dumps({"product_name": product_name})

        response = lambda_client.invoke(
            FunctionName=function_name,
            InvocationType="RequestResponse",
            Payload=payload,
        )

        product_details = json.loads(response["Payload"].read())
        logging.info(f"Product details: {product_details}")

        if product_details["statusCode"] == 200:
            body = json.loads(product_details["body"])
            return {
                "product_link": body.get("product_link"),
                "product_image": body.get("product_image"),
                "product_price": body.get("product_price"),
            }
        else:
            error_message = json.loads(product_details.get("body", "{}")).get(
                "error", "Unknown error"
            )
            logging.error(f"Error getting product details: {error_message}")
            return None

    except json.JSONDecodeError as e:
        logging.error(f"JSON decode error in get_product_details: {str(e)}")
        return None
    except Exception as e:
        logging.error(f"Exception in get_product_details: {str(e)}")
        return None


async def fetch_product_details(product_name, function_name):
    try:
        with st.spinner(f"Loading details for {product_name}..."):
            return await asyncio.to_thread(
                get_product_details, product_name, function_name
            )
    except Exception as e:
        logging.error(f"Error fetching product details: {str(e)}")
        return None


def navigate_arrow_button():
    try:
        if st.session_state.page == "results":
            if st.button(
                "←",
                key="back_arrow_results",
                use_container_width=False,
                help="Go back to the upload page",
            ):
                st.session_state.page = "upload"
                st.rerun()
        elif st.session_state.page == "routine":
            if st.button(
                "←",
                key="back_arrow_routine",
                use_container_width=False,
                help="Go back to the results page",
            ):
                st.session_state.page = "results"
                st.rerun()
    except Exception as e:
        logging.error(f"Error in navigation: {str(e)}")
        st.error("Navigation error occurred")
