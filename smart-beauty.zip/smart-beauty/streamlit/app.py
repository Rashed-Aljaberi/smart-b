import streamlit as st
from utils import add_logo, get_function_names, setup_logging
from pages.selection_page import selection_page
from pages.upload_page import upload_page
from pages.results_page import results_page
from pages.routine_page import routine_page

# Initialize session state
if "page" not in st.session_state:
    st.session_state["page"] = "selection"

# Load CSS
with open("styles/main.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Setup
logger = setup_logging()
function_names = get_function_names()
# Add logo
add_logo()

# Route to appropriate page
if st.session_state["page"] == "selection":
    selection_page()
elif st.session_state["page"] == "upload":
    upload_page(function_names, logger)
elif st.session_state["page"] == "results":
    results_page()
elif st.session_state["page"] == "routine":
    routine_page(function_names, logger)

logger.info("Streamlit app is ready")
