import streamlit as st
from utils import add_logo, get_function_names, setup_logging
from pages.selection_page import selection_page
from pages.upload_page import upload_page
from pages.results_page import results_page
from pages.routine_page import routine_page
from navigation import (
    navigate_to,
    can_go_back,
    can_go_forward,
    go_back,
    go_forward,
    render_nav_buttons,
)


def load_css():
    css_files = [
        "main.css",
        "navigation.css",
        "selection_page.css",
        "upload_page.css",
        "results_page.css",
        "routine_page.css",
        "button_fix.css",  # Add this line
    ]

    print("Starting to load CSS files...")

    css_content = ""
    for css_file in css_files:
        try:
            print(f"Attempting to load {css_file}")
            with open(f"styles/{css_file}") as f:
                css_content += f.read()
            print(f"Successfully loaded {css_file}")
        except Exception as e:
            print(f"Error loading {css_file}: {str(e)}")

    st.markdown(f"<style>{css_content}</style>", unsafe_allow_html=True)


def main():
    # Add viewport meta tag
    st.markdown(
        """
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        """,
        unsafe_allow_html=True,
    )

    # Initialize session state variables
    if "page_history" not in st.session_state:
        st.session_state.page_history = ["selection"]
    if "current_page_idx" not in st.session_state:
        st.session_state.current_page_idx = 0
    if "recommendations_data" not in st.session_state:
        st.session_state.recommendations_data = None
    if "face_analysis" not in st.session_state:
        st.session_state.face_analysis = None
    if "results" not in st.session_state:
        st.session_state.results = None
    if "basket" not in st.session_state:
        st.session_state.basket = []

    # Load CSS
    load_css()

    # Setup
    logger = setup_logging()
    function_names = get_function_names()

    # Add logo
    add_logo()

    # Create navigation context
    nav_context = {
        "navigate_to": navigate_to,
        "can_go_back": can_go_back,
        "can_go_forward": can_go_forward,
        "go_back": go_back,
        "go_forward": go_forward,
    }

    # Render navigation buttons
    nav_col1, nav_col2, _ = st.columns([0.1, 0.1, 2.8])

    with nav_col1:
        if can_go_back():
            if st.button("←", key="nav_back", help="Go back"):
                go_back()
                st.rerun()

    with nav_col2:
        if can_go_forward():
            if st.button("→", key="nav_forward", help="Go forward"):
                go_forward()
                st.rerun()

    # Get current page
    current_page = st.session_state.page_history[st.session_state.current_page_idx]

    # Route to appropriate page
    if current_page == "selection":
        selection_page(nav_context)
    elif current_page == "upload":
        upload_page(function_names, logger, nav_context)
    elif current_page == "results":
        results_page(nav_context)
    elif current_page == "routine":
        routine_page(function_names, logger, nav_context)

    logger.info("Streamlit app is ready")


if __name__ == "__main__":
    main()
