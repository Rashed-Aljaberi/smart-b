import json
import boto3
from botocore.exceptions import ClientError
import time
import os
from json_repair import repair_json
import asyncio

# Initialize DynamoDB client
dynamodb = boto3.resource("dynamodb")
table_name = os.environ["DYNAMODB_TABLE_NAME"]
table = dynamodb.Table(table_name)

# Initialize Bedrock client
bedrock = boto3.client("bedrock-agent-runtime", region_name="us-east-1")


async def invoke_agent(agent_id, agent_alias_id, session_id, input_text):
    return await asyncio.to_thread(
        bedrock.invoke_agent,
        agentId=agent_id,
        agentAliasId=agent_alias_id,
        sessionId=session_id,
        inputText=input_text,
        enableTrace=True,
    )


async def save_to_dynamodb(item):
    return await asyncio.to_thread(table.put_item, Item=item)


def lambda_handler(event, context):
    try:
        age = event.get("age")
        gender = event.get("gender")
        skin_type = event.get("type")
        skin_health = event.get("skin_health")
        skin_concerns = event.get("skin_concerns", [])
        additional_info = event.get("additional_info", "")
        session_id = f"session-{context.aws_request_id}"

        agent_id = os.environ.get("AGENT_ID")
        agent_alias_id = os.environ.get("AGENT_ALIAS_ID")

        if not agent_id or not agent_alias_id:
            raise ValueError(
                "AGENT_ID and AGENT_ALIAS_ID environment variables must be set"
            )

        concerns_text = (
            ", ".join(skin_concerns) if skin_concerns else "no specific concerns"
        )

        input_text = f"""
        Provide a multi-step skincare routine for a {age} {gender} with {skin_type} skin. 
        Their skin health is {skin_health} and they have the following concerns: {concerns_text}.
        Additional information: {additional_info}.
        Tailor your answer to the specific skin concerns, age, skin type etc. 

        IMPORTANT: Your response must be in valid JSON format. Do not include any text outside of the JSON structure.

        The JSON should have the following structure:
        {{
        "routine": [
            {{
            "step": "Step 1: [Product Category]",
            "product": "[Product Name]",
            "alternative": "[Alternative Product Name]",
            "benefits": "Describe the benefits",
            "price": "[Product Price]",
            "score": "[Score]"
            }},
            {{
            "step": "Step 2: [Product Category]",
            "product": "[Product Name]",
            "alternative": "[Alternative Product Name]",
            "benefits": "Describe the benefits",
            "price": "[Product Price]",
            "score": "[Score]"
            }}
            // ... additional steps as needed
        ]
        }}
        Calculate the score based on the following weights:
            - Matching skin type: 30%
            - Addressing specific concerns: 25%
            - Suitability for age: 20%
            - Absence of allergens: 15%
            - Meeting preferences: 10%

        Ensure products with higher scores are recommended first.
        Ensure each product has an alternative suggestion and don't repeat the same products. 
        Remember: The entire response must be valid JSON. Do not include any text or explanations outside of the JSON structure.

        EXAMPLE INPUT:
        - Age: 35
        - Gender: Female
        - Skin Type: Combination
        - Skin Health: Sensitive
        - Concerns: Aging, Hyperpigmentation
        - Additional information: Fragrance-free products 

        EXAMPLE EXPECTED OUTPUT:
        {{
            "routine": [
                {{
                    "step": "Step 1: Cleanser",
                    "product": "Gentle Organic Milk Cleanser",
                    "alternative": "Fragrance-Free Hydrating Cleanser",
                    "benefits": "Removes impurities without stripping natural oils",
                    "price": "$24.99",
                    "score": "92"
                }},
                // Additional steps...
            ]
        }}
        """

        print(f"Invoking agent with input: {input_text}")

        loop = asyncio.get_event_loop()
        response = loop.run_until_complete(
            invoke_agent(agent_id, agent_alias_id, session_id, input_text)
        )

        processed_response = process_agent_response(response)
        print("Processed response:", processed_response)

        item = {
            "sessionId": session_id,
            "age": age,
            "gender": gender,
            "skinType": skin_type,
            "skinHealth": skin_health,
            "skinConcerns": skin_concerns,
            "response": processed_response["agent_response"],
            "timestamp": int(time.time()),
        }
        loop.run_until_complete(save_to_dynamodb(item))

        return {"statusCode": 200, "body": json.dumps(processed_response)}

    except ClientError as e:
        print(f"ClientError occurred: {e}")
        error_code = e.response["Error"]["Code"]
        error_message = e.response["Error"]["Message"]
        if error_code == "ThrottlingException":
            return {
                "statusCode": 429,
                "body": json.dumps(
                    {"error": "throttlingException", "message": error_message}
                ),
            }
        status_code = e.response.get("ResponseMetadata", {}).get("HTTPStatusCode", 400)
        return {
            "statusCode": status_code,
            "body": json.dumps({"error": error_code, "message": error_message}),
        }
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Internal Server Error"}),
        }


def process_agent_response(response):
    print("Processing agent response")
    processed_response = {"agent_response": "", "citations": [], "trace": {}}

    if "completion" in response:
        print("Response contains 'completion'")
        completion = response["completion"]
        for event in completion:
            if "chunk" in event:
                chunk = event["chunk"]
                if "bytes" in chunk:
                    processed_response["agent_response"] += chunk["bytes"].decode(
                        "utf-8"
                    )

                if "attribution" in chunk and "citations" in chunk["attribution"]:
                    for citation in chunk["attribution"]["citations"]:
                        if "generatedResponsePart" in citation:
                            text_part = citation["generatedResponsePart"].get(
                                "textResponsePart", {}
                            )
                            processed_response["citations"].append(
                                {
                                    "text": text_part.get("text", ""),
                                    "span": text_part.get("span", {}),
                                }
                            )

    # Repair and validate JSON
    try:
        repaired_json = repair_json(processed_response["agent_response"])
        json.loads(repaired_json)  # Validate JSON
        processed_response["agent_response"] = repaired_json
    except json.JSONDecodeError as e:
        print(f"JSON repair failed: {str(e)}")
        processed_response["agent_response"] = "{}"  # Return empty JSON if repair fails

    return processed_response
