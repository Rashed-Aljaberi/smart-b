import json
import requests
from bs4 import BeautifulSoup
import time
import random
from requests.exceptions import RequestException

# Expanded list of user agents for better rotation
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 11.5; rv:89.0) Gecko/20100101 Firefox/89.0",
]


def get_headers():
    """Generate headers with a randomly selected user agent."""
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "DNT": "1",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
    }


def scrape_product_details(product_name, max_retries=3):
    """
    Scrape product details from Amazon with robust error handling.

    Args:
        product_name (str): Name of the product to search
        max_retries (int): Maximum number of retry attempts

    Returns:
        dict or None: Product details or None if scraping fails
    """
    product_name = product_name.strip()

    for attempt in range(max_retries):
        try:
            # Randomized delay to mimic human-like behavior
            time.sleep(random.uniform(2, 5))

            # URL encode the product name
            encoded_product_name = product_name.replace(" ", "+")
            search_url = f"https://www.amazon.fr/s?k={encoded_product_name}"

            # Make request with rotated user agent
            response = requests.get(
                search_url,
                headers=get_headers(),
                timeout=10,  # Add timeout to prevent hanging
            )

            # Raise an exception for bad status codes
            response.raise_for_status()

            # Parse the HTML
            soup = BeautifulSoup(response.text, "html.parser")
            product = soup.select_one("div[data-component-type='s-search-result']")

            if not product:
                print(f"No product found for '{product_name}' on attempt {attempt + 1}")
                continue

            # Extract product details
            product_link = product.select_one("a.a-link-normal")
            product_image = product.select_one("img.s-image")
            product_price = product.select_one("span.a-offscreen")

            return {
                "product_link": (
                    "https://www.amazon.fr" + product_link["href"]
                    if product_link
                    else None
                ),
                "product_image": product_image["src"] if product_image else None,
                "product_price": product_price.text if product_price else None,
            }

        except RequestException as e:
            print(f"Attempt {attempt + 1} failed for '{product_name}': {e}")

            # Exponential backoff
            time.sleep(2**attempt)

    print(
        f"Failed to scrape product details for '{product_name}' after {max_retries} attempts"
    )
    return None


def create_response(status_code, body=None):
    """Create a standardized response for AWS Lambda."""
    response = {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "GET,OPTIONS",
        },
    }
    if body:
        response["body"] = json.dumps(body)
    return response


def lambda_handler(event, context):
    """AWS Lambda handler function."""
    if event.get("httpMethod") == "OPTIONS":
        return create_response(200)

    product_name = event.get("product_name")
    if not product_name:
        return create_response(400, {"error": "Missing product_name parameter"})

    details = scrape_product_details(product_name)
    if not details:
        return create_response(
            404, {"error": f"No product details found for '{product_name}'"}
        )

    return create_response(
        200,
        {
            "product_name": product_name,
            "product_link": details["product_link"],
            "product_image": details["product_image"],
            "product_price": details["product_price"],
        },
    )
