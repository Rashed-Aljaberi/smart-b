import json
import base64
import asyncio
import aioboto3
from json_repair import repair_json


async def analyze_with_nova(image_bytes):
    async with aioboto3.Session().client("bedrock-runtime") as bedrock_client:
        # Define system prompts for skin and facial feature analysis
        system_prompts = [
            {
                "text": (
                    "You are a skincare and facial analysis expert. Analyze the provided image for skin type, "
                    "health, visible concerns, gender, and estimated age. Return the results in JSON format, no markdown, no special characters, pure json, with the following structure: "
                    "{\n"
                    '  "skinType": "",\n'
                    '  "skinHealth": "",\n'
                    '  "skinConcerns": [],\n'
                    '  "gender": "",\n'
                    '  "estimatedAge": ""\n'
                    "}"
                )
            }
        ]

        # Prepare the Base64 encoded image
        base64_string = base64.b64encode(image_bytes).decode("utf-8")

        # Define user messages including both the image and a text prompt
        message_list = [
            {
                "role": "user",
                "content": [
                    {
                        "image": {
                            "format": "jpeg",
                            "source": {"bytes": base64_string},
                        }
                    },
                    {
                        "text": "Analyze this image for skin type, overall skin health, and visible concerns."
                    },
                ],
            }
        ]

        # Configure inference parameters
        inf_params = {
            "max_new_tokens": 300,
            "top_p": 0.9,
            "top_k": 50,
            "temperature": 0.5,
        }

        # Construct the request body
        request_body = {
            "schemaVersion": "messages-v1",
            "messages": message_list,
            "system": system_prompts,
            "inferenceConfig": inf_params,
        }

        print("Calling the Nova model...")

        # Invoke the Nova Pro model
        response = await bedrock_client.invoke_model(
            modelId="us.amazon.nova-pro-v1:0",
            body=json.dumps(request_body),
        )
        print("Response received from the model.")
        try:
            response_body = json.loads(await response["body"].read())
            return response_body
        except json.JSONDecodeError:
            # If invalid JSON, attempt to repair
            try:
                repaired_json = repair_json(response["body"].read())
                return json.loads(repaired_json)
            except json.JSONDecodeError:
                # If repair fails, return an error message
                return {"error": "Invalid JSON response from LLM"}


async def analyze_face(image_bytes):
    nova_result = await analyze_with_nova(image_bytes)
    return nova_result


def lambda_handler(event, context):
    try:
        image_bytes = base64.b64decode(event["image"])
        result = asyncio.run(analyze_face(image_bytes))

        if result:
            print(result)
            return {"statusCode": 200, "body": json.dumps(result)}
        else:
            return {
                "statusCode": 404,
                "body": json.dumps({"error": "No face detected in the image"}),
            }
    except Exception as e:
        print(f"Error analyzing face: {str(e)}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": f"Error analyzing face: {str(e)}"}),
        }
